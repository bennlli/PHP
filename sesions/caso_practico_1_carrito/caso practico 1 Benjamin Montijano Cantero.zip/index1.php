<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
</head>
<body>
    <!--
        Un index.php que enlace a los 4 productos que se pueden comprar y a la página de carrito.
    -->
<?php
// primero va el nombre del archivo, 2 va lo que seria la cookien en si, luego el tiempo


?>
<a href="producto_1.html">Producto 1</a><br><br>
<a href="producto_2.html">Producto 2</a><br><br>
<a href="producto_3.html">Producto 3</a><br><br>
<a href="producto_4.html">Producto 4</a><br><br>

    <a href="carrito.php">Este enlace te llavara al carrito.</a>
</body>
</html>